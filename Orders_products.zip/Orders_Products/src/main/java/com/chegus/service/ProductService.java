package com.chegus.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chegus.entities.Product;
import com.chegus.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;

	public void save(Product product) {
		productRepository.save(product);
	}

	public List<Product> getAllProducts() {
		return productRepository.getAllProducts();
	}

	public Product getProductById(Integer productId) {
		return productRepository.getProductById(productId);
	}

	public boolean checkProductName(String productName) {
		return productRepository.checkProductNameExist(productName);
	}
}
