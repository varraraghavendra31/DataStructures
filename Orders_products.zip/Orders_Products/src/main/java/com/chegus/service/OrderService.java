package com.chegus.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chegus.entities.OrderProduct;
import com.chegus.entities.Orders;
import com.chegus.entities.Product;
import com.chegus.repository.OrderProductRepository;
import com.chegus.repository.OrderRepository;
import com.chegus.repository.ProductRepository;

@Service
public class OrderService {
	@Autowired
	ProductRepository productRepository;

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	OrderProductRepository orderProductRepository;

	public List<Orders> getOrders() {
		List<Orders> list = orderRepository.getAllOrders();
		return list;
	}

	public Integer saveOrders(Orders orders) {

		Integer orderId = null ;
		
		boolean flag = false;
		List<OrderProduct> newOrderProducts = orders.getProducts();
		if (orders.getOrderId() != null) {
			orderId = orders.getOrderId();
			orderRepository.saveOrders(orders);
			
			List<OrderProduct> dataBaseOrderProducts = orderProductRepository.getOrderProductsById(orderId);

			for (OrderProduct newOrderProduct : newOrderProducts) {
				newOrderProduct.setOrders(orders);
				if (dataBaseOrderProducts.contains(newOrderProduct)
						|| !dataBaseOrderProducts.contains(newOrderProduct)) {
					if (newOrderProduct.getQuntity() != null) {
						orderProductRepository.saveOrderProduct(newOrderProduct);
					}
				}
			}
			for (OrderProduct orderProduct : dataBaseOrderProducts) {
				if (!newOrderProducts.contains(orderProduct)) {
					orderProductRepository.delete(orderProduct);
				}
			}

			flag = true;
		}
		if (!flag) {
			orderId = orderRepository.saveOrders(orders);
			for (OrderProduct newOrderProduct : newOrderProducts) {
				newOrderProduct.setOrders(orders);
				orderProductRepository.saveOrderProduct(newOrderProduct);
			}
		}
	return 	orderId;
	}

	public void removeById(Integer orderId) {
		Orders order = orderRepository.findById(orderId);
		orderRepository.delete(order);
	}

	public Orders findById(Integer orderId) {
		Orders order = orderRepository.findById(orderId);
		if (order != null)
			return order;
		return null;
	}

//	    
//		@Transactional
//	    public List<OrderProduct> getOrderWithProducts(Integer orderId) {
//	        Orders orders = orderRepository.findById(orderId);
//	        List<OrderProduct> orderProducts =orders.getProducts();
//	         return  orderProducts;
//	    }

	public List<Orders> searchOrders(String id, String name) {
		return orderRepository.searchOrders(id, name);

	}

}
