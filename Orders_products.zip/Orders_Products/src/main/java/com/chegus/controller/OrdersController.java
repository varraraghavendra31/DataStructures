package com.chegus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.chegus.entities.Orders;
import com.chegus.entities.Product;
import com.chegus.service.OrderService;
import com.chegus.service.ProductService;

@Controller
public class OrdersController {

	
	@Autowired
	OrderService orderService;

	@Autowired
	ProductService productService;

	@RequestMapping("/")
	public ModelAndView view() {
       
		
		
		List<Orders> order = orderService.getOrders();
		ModelAndView mv = new ModelAndView("display");
		mv.addObject("ordersList", order);
		return mv;
	}

	@RequestMapping("/createProduct")
	public ModelAndView registerProduct() {

		ModelAndView mv = new ModelAndView("product");
		mv.addObject("product", new Product());
		return mv;
	}

	@RequestMapping("saveProduct")
	public String addProduct(@ModelAttribute Product product) {
		productService.save(product);
		return "redirect:/";

	}

	@RequestMapping("/createOrder")
	public ModelAndView createOrder(@ModelAttribute("orders") Orders orders) {
		ModelAndView mv = new ModelAndView();
		List<Product> Products = productService.getAllProducts();
		mv.addObject("allProducts", Products);
		mv.setViewName("orders");
		mv.addObject("orders", orders);
		return mv;
	}

	@RequestMapping(value = { "/saveOrder", "/editOrder/saveOrder"}, method = RequestMethod.POST)
	@ResponseBody
	public String saveOrder(@ModelAttribute Orders orders) {
		Integer responseOrderId = orderService.saveOrders(orders);
		return String.valueOf(responseOrderId);
		
	}

	@RequestMapping("/deleteOrder/{id}")
	public ModelAndView deleteOrder(@PathVariable("id") Integer orderId) {
		orderService.removeById(orderId);
		ModelAndView mv = new ModelAndView("redirect:/");
		mv.addObject("message", "data deleted successfully");
		return mv;
	}

	@RequestMapping(value="/editOrder",method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView editForm(@RequestParam("id") Integer orderId) {
		ModelAndView mav = new ModelAndView("orders");
		Orders orders = orderService.findById(orderId);
		List<Product> products = productService.getAllProducts();
		mav.addObject("allProducts", products);
		mav.addObject("orders", orders);
		return mav;
	}

	@RequestMapping(value = "searchOrders", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView searchOrders(@RequestParam(name = "id") String id, @RequestParam(name = "name") String name) {

		List<Orders> orders = orderService.searchOrders(id, name);
		ModelAndView mav = new ModelAndView("display");
		mav.addObject("ordersList", orders);
		if (orders == null) {
			mav.addObject("message", " No records found");
		}
		return mav;
	}

	@RequestMapping("/displayOrders")
	public ModelAndView searchDisplay() {
		return new ModelAndView("redirect:/");
	}

	@RequestMapping("/getProductPrice")
	@ResponseBody
	public String getProductPrice(@RequestParam("productId") Integer productId) {
		Product product = productService.getProductById(productId);
		if (product != null) {
			return String.valueOf(product.getPrice());
		} else {
			return "Product not found";
		}
	}

	@RequestMapping("/checkProductExist")
	@ResponseBody
	public String checkProductExists(@RequestParam("name") String productName) {
		boolean name = productService.checkProductName(productName);
		if (name) {
			return "";
		}
		return "product Exist";

	}
}
