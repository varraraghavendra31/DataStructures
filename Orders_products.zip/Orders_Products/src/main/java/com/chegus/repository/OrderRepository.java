package com.chegus.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.chegus.config.HibernateUtil;
import com.chegus.entities.OrderProduct;
import com.chegus.entities.Orders;

@Repository
public class OrderRepository {

	public List<Orders> getAllOrders() {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();
		Query<Orders> query = session.createQuery("FROM Orders o", Orders.class);
		List<Orders> list = query.getResultList();
		System.out.println(list);
		tx.commit();
		session.close();
		return list;

	}

	public Integer saveOrders(Orders orders) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		try {
			Transaction tx = session.beginTransaction();
			session.saveOrUpdate(orders);
			tx.commit();
		}
		finally{
			session.close();
		}
		 Integer orderId = orders.getOrderId();
		 System.out.println("Saved Order ID: " + orderId);
		 return orderId;
	}

	public Orders findById(Integer orderId) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();
//		Orders orders = session.load(Orders.class, orderId);
		Orders orders = session.get(Orders.class, orderId);
		List<OrderProduct> orderProducts = null;

		if (Hibernate.isInitialized(orders.getProducts())) {
			orderProducts = orders.getProducts();
		} else {
			Hibernate.initialize(orders.getProducts());
			orderProducts = orders.getProducts();
		}
		tx.commit();
		session.close();

		return orders;

	}

	public void delete(Orders order) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();
		if (order != null) {
			session.remove(order);
		}
		tx.commit();
		session.close();
	}

	public List<Orders> searchOrders(String id, String customerName) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Orders> criteriaQuery = criteriaBuilder.createQuery(Orders.class);
		Root<Orders> root = criteriaQuery.from(Orders.class);

		List<Predicate> predicates = new ArrayList<>();

		if (id != null && !id.isEmpty()) {
			predicates.add(criteriaBuilder.equal(root.get("orderId"), Integer.parseInt(id)));
		}

		if (customerName != null && !customerName.isEmpty()) {
			predicates.add(criteriaBuilder.like(root.get("customerName"), "%" + customerName + "%"));
		}

		criteriaQuery.where(predicates.toArray(new Predicate[0]));

		TypedQuery<Orders> query = session.createQuery(criteriaQuery);
//    		session.close();
		return query.getResultList();

	}

}
