package com.chegus.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.chegus.config.HibernateUtil;
import com.chegus.entities.OrderProduct;

@Repository
public class OrderProductRepository {
	
	public void saveOrderProduct(OrderProduct orderProducts) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(orderProducts);
		tx.commit();
		session.close();
	}
	
	public List<OrderProduct> getOrderProductsById(Integer orderId) {
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		Query<OrderProduct> query = session.createQuery("FROM OrderProduct op WHERE op.orders.orderId = :orderId", OrderProduct.class);
		query.setParameter("orderId", orderId);
		List<OrderProduct> list = query.getResultList();
		tx.commit();
		session.close();
		return list;
		
	}
	
	public void delete(OrderProduct orderProduct) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		if(orderProduct!=null) {
			session.remove(orderProduct);
		}
		tx.commit();
		session.close();
	}
	
}