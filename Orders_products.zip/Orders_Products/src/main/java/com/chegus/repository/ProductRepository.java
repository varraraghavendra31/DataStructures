package com.chegus.repository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.chegus.config.HibernateUtil;
import com.chegus.entities.Product;

@Repository
public class ProductRepository {

	public void save(Product product) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(product);
		tx.commit();
		session.close();
	}

	public List<Product> getAllProducts() {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();

		Query<Product> query = session.createQuery("FROM Product p", Product.class);
		List<Product> set =  query.getResultList();
				     
		  System.out.println(set);
		  tx.commit();
		  session.close();
		  return set;
	}

	public Product getProductById(Integer productId) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		Product product = session.find(Product.class,productId);
		 session.close();
		return product;	
	}

	public boolean checkProductNameExist(String productName) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction tx = session.beginTransaction();
		
		Query<Product> query = session.createQuery("FROM Product p WHERE p.productName= :productName", Product.class);
		query.setParameter("productName", productName);
		List<Product> list =  query.getResultList();
		session.close();
		return list.isEmpty();
	}
}
